# Carvão Editor AI — v0.2

Primeiro protótipo funcional de editor de vídeo Android.

## Recursos
- Importar um vídeo do aparelho.
- Pré-visualizar e reproduzir/pausar.
- Definir os pontos de início e fim do trecho em segundos.
- Exportar o trecho selecionado para MP4 usando Media3 Transformer.
- Salvar o resultado em Filmes/CarvaoEditorAI.

## Compilar APK
O workflow `.github/workflows/android.yml` compila um APK de depuração e publica o arquivo como artefato do GitHub Actions.

1. Envie estes arquivos para a raiz do repositório `carvao-editor-ai`.
2. Abra a aba **Actions**.
3. Execute **Build Android APK** ou aguarde o workflow iniciado pelo push.
4. Abra uma execução concluída e baixe `Carvao-Editor-AI-debug-apk`.

## Limitações desta versão
- O corte é feito por um único trecho contínuo.
- A precisão do ponto de corte depende do formato/codec do vídeo e do processamento do Transformer.
- Não inclui ainda múltiplas faixas, transições, legendas automáticas ou recursos de IA.
- O APK de depuração não é um aplicativo publicado na Play Store.
