package com.carvao.editorai

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.VideoView
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var videoView: VideoView
    private lateinit var status: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var exportButton: Button
    private lateinit var progress: ProgressBar
    private var selectedVideo: Uri? = null
    private var durationMs: Int = 0
    private var outputTemp: File? = null
    private val pickVideoRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 12)
        window.navigationBarColor = Color.rgb(12, 12, 12)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(12, 12, 12))
        }

        root.addView(TextView(this).apply {
            text = "CARVÃO  /  EDITOR AI"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }, lpMatch(dp(48)))

        root.addView(TextView(this).apply {
            text = "IMPORTAR • CORTAR • EXPORTAR"
            textSize = 11f
            setTextColor(Color.rgb(160, 160, 160))
        }, lpMatch(dp(26)))

        videoView = VideoView(this).apply {
            setBackgroundColor(Color.rgb(28, 28, 28))
        }
        root.addView(videoView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        status = TextView(this).apply {
            text = "Importe um vídeo para começar."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(status, lpMatch(dp(42)))

        val importButton = makeButton("＋  IMPORTAR VÍDEO") {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*" }
            startActivityForResult(Intent.createChooser(intent, "Escolher vídeo"), pickVideoRequest)
        }
        root.addView(importButton, lpMatch(dp(50)))

        root.addView(TextView(this).apply {
            text = "CORTE (segundos)"
            textSize = 12f
            setTextColor(Color.rgb(180, 180, 180))
        }, lpMatch(dp(30)))

        val times = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        startInput = makeTimeInput("Início: 0")
        endInput = makeTimeInput("Fim: segundos")
        times.addView(startInput, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        times.addView(endInput, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        root.addView(times, lpMatch(dp(58)))

        root.addView(TextView(this).apply {
            text = "Exemplo: início 5 e fim 18 exporta do segundo 5 ao 18."
            textSize = 11f
            setTextColor(Color.rgb(135, 135, 135))
        }, lpMatch(dp(28)))

        exportButton = makeButton("✂  CORTAR E EXPORTAR MP4") { exportClip() }
        root.addView(exportButton, lpMatch(dp(52)))

        progress = ProgressBar(this).apply { visibility = ProgressBar.GONE }
        root.addView(progress, lpMatch(dp(8)))

        root.addView(TextView(this).apply {
            text = "V0.2 • Corte de trecho único • Exportação MP4"
            textSize = 10f
            setTextColor(Color.rgb(125, 125, 125))
            gravity = Gravity.CENTER
        }, lpMatch(dp(26)))

        setContentView(root)
    }

    private fun makeTimeInput(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.GRAY)
        setTextColor(Color.WHITE)
        textSize = 14f
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or
            android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(dp(10), 0, dp(10), 0)
        setBackgroundColor(Color.rgb(36, 36, 36))
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(55, 55, 55))
        setOnClickListener { action() }
    }

    @Deprecated("Deprecated in Android, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoRequest && resultCode == RESULT_OK) {
            data?.data?.let { loadVideo(it) }
        }
    }

    private fun loadVideo(uri: Uri) {
        selectedVideo = uri
        status.text = "Carregando vídeo..."
        videoView.setVideoURI(uri)
        videoView.setOnErrorListener { _, _, _ ->
            status.text = "Não foi possível abrir este vídeo. Tente outro arquivo."
            true
        }
        videoView.setOnPreparedListener { player ->
            durationMs = player.duration.coerceAtLeast(0)
            startInput.setText("0")
            endInput.setText(String.format(Locale.US, "%.1f", durationMs / 1000.0))
            status.text = "Vídeo pronto • duração ${formatTime(durationMs)}"
        }
        videoView.setOnCompletionListener { videoView.seekTo(0) }
        videoView.start()
    }

    private fun exportClip() {
        val uri = selectedVideo
        if (uri == null) {
            status.text = "Importe um vídeo primeiro."
            return
        }
        val startSeconds = startInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val endSeconds = endInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (startSeconds == null || endSeconds == null || startSeconds < 0 || endSeconds <= startSeconds) {
            status.text = "Informe um início e um fim válidos em segundos."
            return
        }
        val startMs = (startSeconds * 1000).toLong()
        val endMs = (endSeconds * 1000).toLong()
        if (durationMs > 0 && endMs > durationMs) {
            status.text = "O fim ultrapassa a duração do vídeo (${formatTime(durationMs)})."
            return
        }

        try {
            videoView.pause()
            exportButton.isEnabled = false
            progress.visibility = ProgressBar.VISIBLE
            status.text = "Preparando exportação..."
            val clip = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
                .build()
            val editedItem = EditedMediaItem.Builder(clip).build()
            val file = File(cacheDir, "carvao_export_${System.currentTimeMillis()}.mp4")
            outputTemp = file
            val transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        runOnUiThread {
                            saveExportToMovies(file)
                        }
                    }

                    override fun onError(
                        composition: androidx.media3.transformer.Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        runOnUiThread {
                            exportButton.isEnabled = true
                            progress.visibility = ProgressBar.GONE
                            status.text = "Falha ao exportar: ${exportException.message ?: "formato não suportado"}"
                            file.delete()
                        }
                    }
                })
                .build()
            transformer.start(editedItem, file.absolutePath)
        } catch (e: Exception) {
            exportButton.isEnabled = true
            progress.visibility = ProgressBar.GONE
            status.text = "Não foi possível iniciar: ${e.message ?: "erro desconhecido"}"
        }
    }

    private fun saveExportToMovies(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "Carvao_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/CarvaoEditorAI")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = contentResolver
            val outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Não foi possível criar o arquivo de saída.")
            resolver.openOutputStream(outputUri).use { output ->
                if (output == null) throw IllegalStateException("Não foi possível abrir o destino.")
                FileInputStream(file).use { input -> input.copyTo(output) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(outputUri, values, null, null)
            file.delete()
            exportButton.isEnabled = true
            progress.visibility = ProgressBar.GONE
            status.text = "Exportado! Abra Galeria > Vídeos ou Filmes/CarvaoEditorAI."
        } catch (e: Exception) {
            exportButton.isEnabled = true
            progress.visibility = ProgressBar.GONE
            status.text = "O corte terminou, mas salvar falhou: ${e.message ?: "erro desconhecido"}"
        }
    }

    private fun formatTime(ms: Int): String {
        val total = ms.coerceAtLeast(0) / 1000
        return "%02d:%02d".format(total / 60, total % 60)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun lpMatch(height: Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)
}
